
async function getWeather() {
  const city = document.getElementById('cityInput').value;
  const apiKey = '032865e0f7b8decf66e54a423d60a31a';
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error('City not found');
    const data = await response.json();

    const weather = `
      <p><strong>${data.name}</strong></p>
      <p>Temperature: ${data.main.temp}°C</p>
      <p>Weather: ${data.weather[0].description}</p>
      <p>Humidity: ${data.main.humidity}%</p>
    `;
    document.getElementById('result').innerHTML = weather;
  } catch (error) {
    document.getElementById('result').innerHTML = '<p>City not found. Please try again.</p>';
  }
}
